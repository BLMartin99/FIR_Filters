% ---------------------------------
% PhasorRaces (phrace) version 1.00
% ---------------------------------
%
% The concept and original code for this program was developed by
% Dr. James H. McClellan.
%
% If you have any questions or comments, please feel free to send
% email to Dr. McClellan (james.mcclellan@ece.gatech.edu).
%
% Georgia Institute of Technology, Atlanta, GA
% School of ECE
%

% $Revision: 1.0 $
% Rajbabu, Aug-06-2002

