%COntinuous-Time Linear Time Invariance System Demo version 1.00
%
%This program was modified by Mustayeen Nayeem. The purpose of the GUI is 
%to assist students in attaining more understanding about continuous-time LTI systems.
%
%I personally would like to Thank Jordan Rosenthal (jr@ee.gatech.edu) 
%for his significant helps in writing this GUI. Some of the MATLAB 
%functions that I used in this GUI is written by him. In addition, I 
%also had modified some of his functions to fit into my needs.
%
%If you have any questions or comments, please feel free to send me
%email to gte014g@prism.gatech.edu
%
%Georgia Institute of Technology, Atlanta, GA
%School of ECE
%Winter/Spring 1999
%
%Updated 18-May-1999 by J. McClellan
%Updated 05-Nov-2000 by Jordan Rosenthal
%Updated 20-Aug-2001 by Mustayeen Nayeem
