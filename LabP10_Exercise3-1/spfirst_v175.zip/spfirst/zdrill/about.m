%ZDrill version 2.05
%---------------------
%
%The concept and original code for this program was developed by
%Dr. James H. McClellan for the DSP First book.  The code for versions
%2.0 and higher were written by Jordan Rosenthal.
%
%If you have any questions or comments, please feel free to send
%email to either Jordan Rosenthal (jr@ece.gatech.edu) or Dr. McClellan
%(james.mcclellan@ece.gatech.edu).
%
%Georgia Institute of Technology, Atlanta, GA
%School of ECE
%
% - Jordan Rosenthal, 05-Nov-2000
